### Hexlet tests and linter status:
[![Actions Status](https://github.com/Dmitri-Bes/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Dmitri-Bes/python-project-49/actions)

#bage
[![Maintainability](https://api.codeclimate.com/v1/badges/615bb054f2a3b512a5c6/maintainability)](https://codeclimate.com/github/Dmitri-Bes/python-project-49/maintainability)

#asciinema brain-even game
[![asciicast](https://asciinema.org/a/564922.svg)](https://asciinema.org/a/564922)

#asciinema brain-calc game
[![asciicast](https://asciinema.org/a/566430.svg)](https://asciinema.org/a/566430)

#asciinema brain-gcd game
[![asciicast](https://asciinema.org/a/566442.svg)](https://asciinema.org/a/566442)

#asciinema brain-progression game
[![asciicast](https://asciinema.org/a/566487.svg)](https://asciinema.org/a/566487)

#asciinema brain-prime game
[![asciicast](https://asciinema.org/a/566494.svg)](https://asciinema.org/a/566494)