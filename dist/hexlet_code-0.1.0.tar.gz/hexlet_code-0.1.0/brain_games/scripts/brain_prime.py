from brain_games.opti.game_dev import log, come


road = 'brain_games.games.prime'


def main():
    come(road)
    log()


if __name__ == '__main__':
    main()
