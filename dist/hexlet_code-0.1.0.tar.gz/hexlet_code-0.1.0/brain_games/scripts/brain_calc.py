#!/usr/bin/env python3


from brain_games.opti.game_dev import log, come


road = 'brain_games.games.calc'


def main():
    come(road)
    log()


if __name__ == '__main__':
    main()