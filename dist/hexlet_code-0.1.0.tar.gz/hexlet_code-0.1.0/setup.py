# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.opti', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Dmitri-Bes/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Dmitri-Bes/python-project-49/actions)\n\n#bage\n[![Maintainability](https://api.codeclimate.com/v1/badges/615bb054f2a3b512a5c6/maintainability)](https://codeclimate.com/github/Dmitri-Bes/python-project-49/maintainability)\n\n#asciinema brain-even game\n[![asciicast](https://asciinema.org/a/564922.svg)](https://asciinema.org/a/564922)\n\n#asciinema brain-calc game\n[![asciicast](https://asciinema.org/a/566430.svg)](https://asciinema.org/a/566430)\n\n#asciinema brain-gcd game\n[![asciicast](https://asciinema.org/a/566442.svg)](https://asciinema.org/a/566442)\n\n#asciinema brain-progression game\n[![asciicast](https://asciinema.org/a/566487.svg)](https://asciinema.org/a/566487)\n\n#asciinema brain-prime game\n[![asciicast](https://asciinema.org/a/566494.svg)](https://asciinema.org/a/566494)',
    'author': 'Dmitriy Bes',
    'author_email': 'beskorovainiy.dmitri@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
